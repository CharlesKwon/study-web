// 요소를 선택하여 변수에 저장한다.
var el = document.getElementById('one');

// 요소의 css 특성 값을 변경한다.
el.className = 'cool';
