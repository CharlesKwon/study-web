function BasketCtrl($scope) {
  $scope.description = '1회 입장권';
  $scope.cost = 8;
  $scope.qty = 1;
}